#include <iostream>

// BEGIN YOUR CLASS/FUNCTION


// END YOUR CLASS/FUNCTION


int main() {
    
    // BEGIN YOUR CODE


    // END YOUR CODE

    return 0;
}