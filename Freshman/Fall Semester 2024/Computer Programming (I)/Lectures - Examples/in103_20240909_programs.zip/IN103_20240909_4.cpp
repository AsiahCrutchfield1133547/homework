#include <iostream>
using namespace std;

// THIS IS A COMMENT AND IS OMITTED BY THE COMPILER

int main()
{
   cout << "Hello!" << 3 + 8 << endl; // this prints
}

