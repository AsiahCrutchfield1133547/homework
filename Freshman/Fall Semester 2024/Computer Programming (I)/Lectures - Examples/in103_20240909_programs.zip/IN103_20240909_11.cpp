#include <iostream>
using namespace std;

int main()
{
   cout << 7 / 2 << endl; // 3 rather than 3.5, integer division
   cout << 7 % 2 << endl; // 7 modulo 2 takes the remainder
   cout << 15 % 4 << endl; // 3
   cout << 7.0 / 2.0 << endl; // 3.5
}

